//
//  ViewController.swift
//  Player
//
//  Created by 周伟克 on 2021/3/12.
//

import UIKit
import TXLiteAVSDK_Player

class ViewController: UIViewController {

    let player = TXVodPlayer()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        player.enableHWAcceleration = true
        
        player.setupVideoWidget(view, insert: 0)
        player.startPlay("https://ilook.yun.chinahrt.com/courseyun/hbzj/transcode/20208/8cb0ee9c-d9a8-40ae-aee1-ea6b04d3a9be/283007-mp4.mp4")
    }
    
    
}

